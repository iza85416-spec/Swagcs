# SWAG.CS - Render дээр ажиллуулах

## Бүтэц
- `server.mjs` - сервер (static + бүх API)
- `functions/` - Steam нэвтрэлт, leaderboard, skin, зураг, Discord (`steam.mjs`, `discord.mjs`), `ratings.json`, `staff.json`
- `public/index.html` - сайт

## GitHub -> Render
1. Энэ хавтсыг **private** GitHub repo болгож оруулна.
2. Render -> New -> Web Service -> repo-гоо сонгоно. Build Command: `echo no build`, Start Command: `npm start`.
3. Environment хэсэгт:
   - `BASE_URL` = `https://таны-домэйн.mn` (эсвэл Render-ийн `https://xxx.onrender.com`), төгсгөлд `/` байхгүй
   - `SESSION_SECRET` = урт санамсаргүй тэмдэгт мөр
   - `STEAM_API_KEY` = заавал биш
   - `DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET` = Discord холболт хэрэгтэй бол
4. Discord Developer Portal -> OAuth2 -> Redirects: `BASE_URL/auth/discord/callback`

## Анхаарах
- Skin/профайл зураг `DATA_DIR` (`/var/data`) дотор хадгалагдана. Render-ийн үнэгүй plan дээр файл redeploy бүрт арилдаг. Үлдээхийг хүсвэл төлбөртэй plan дээр Disk холбоод mount path-ийг `/var/data` болгоно.
- Leaderboard-ийн өгөгдөл `functions/ratings.json` (эсвэл `RATINGS_URL`), staff нь `functions/staff.json`.
- Нууц түлхүүрийг GitHub-д бүү оруул.
