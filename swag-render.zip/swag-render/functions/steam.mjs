// Netlify Function: бодит Steam нэвтрэлт (OpenID 2.0). Cookie-д гарын үсэгтэй session хадгална (серверийн төлөвгүй).
import crypto from 'node:crypto';
import { readFileSync } from 'node:fs';

export const config = { path: ['/auth/steam', '/auth/steam/return', '/api/me', '/api/logout', '/api/skins', '/api/leaderboard', '/api/pfimg', '/api/player', '/api/team'] };

const OPENID = 'https://steamcommunity.com/openid/login';
const NS = 'http://specs.openid.net/auth/2.0';

const secret = () => {
  const s = process.env.SESSION_SECRET;
  if (!s) throw new Error('SESSION_SECRET env variable is not set');
  return s;
};
const sign = v => crypto.createHmac('sha256', secret()).update(v).digest('base64url');
const makeCookie = o => { const b = Buffer.from(JSON.stringify(o)).toString('base64url'); return b + '.' + sign(b); };
function readCookie(req) {
  const m = /(?:^|;\s*)swag=([^;]+)/.exec(req.headers.get('cookie') || ''); if (!m) return null;
  const [b, s] = m[1].split('.'); if (!b || !s) return null;
  const a = Buffer.from(sign(b)), c = Buffer.from(s);
  if (a.length !== c.length || !crypto.timingSafeEqual(a, c)) return null;
  try { const o = JSON.parse(Buffer.from(b, 'base64url').toString()); return o.exp > Date.now() ? o : null; } catch { return null; }
}
const cookieHdr = (v, age) => `swag=${v}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${age}`;
const redirect = (loc, extra = {}) => new Response(null, { status: 302, headers: { Location: loc, ...extra } });
const json = (code, o, extra = {}) => new Response(JSON.stringify(o), { status: code, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', ...extra } });

async function verify(url, base) {
  const q = Object.fromEntries(url.searchParams);
  if (q['openid.ns'] !== NS || q['openid.mode'] !== 'id_res') return null;
  if (!(q['openid.return_to'] || '').startsWith(base + '/auth/steam/return')) return null;
  const p = new URLSearchParams(url.searchParams); p.set('openid.mode', 'check_authentication');
  const r = await fetch(OPENID, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: p });
  if (!/is_valid\s*:\s*true/.test(await r.text())) return null;
  const m = /^https:\/\/steamcommunity\.com\/openid\/id\/(\d{17})$/.exec(q['openid.claimed_id'] || '');
  return m ? m[1] : null;
}

// Rating: RATINGS_URL (JSON) эсвэл netlify/functions/ratings.json. Формат: {"7656119...": 1850} эсвэл [{"steamid":"7656119...","rating":1850}]
const nn = x => Math.max(0, Math.round(+x || 0));
function norm(id, v) {
  if (v == null) return null;
  if (typeof v !== 'object') return { id, rating: nn(v), stats: null };
  const stats = { kills: nn(v.kills ?? v.k), deaths: nn(v.deaths ?? v.d), assists: nn(v.assists ?? v.a), wins: nn(v.wins ?? v.w), losses: nn(v.losses ?? v.l),
    hs: nn(v.hs), shots: nn(v.shots), hits: nn(v.hits), damage: nn(v.damage ?? v.dmg), time: v.time || '', last: v.last || '' };
  return { id, rating: nn(v.rating ?? v.exp), stats: (stats.kills || stats.deaths || stats.wins || stats.losses) ? stats : null };
}
async function loadAll() {
  let d;
  if (process.env.RATINGS_URL) d = await (await fetch(process.env.RATINGS_URL)).json();
  else d = JSON.parse(readFileSync(new URL('./ratings.json', import.meta.url), 'utf8'));
  const arr = Array.isArray(d) ? d : (d.players || null);
  if (arr) return arr.map(x => norm(String(x.steamid || x.id || x.steamId), x)).filter(Boolean);
  return Object.keys(d).map(k => norm(k, d[k])).filter(Boolean);
}
async function ratingOf(id) {
  try {
    const all = (await loadAll()).filter(x => x.rating > 0).sort((a, b) => b.rating - a.rating);
    const i = all.findIndex(x => x.id === id);
    return i < 0 ? { rating: 0, stats: null, place: 0, players: all.length } : { rating: all[i].rating, stats: all[i].stats, place: i + 1, players: all.length };
  } catch (e) { console.error('rating', e.message); return { rating: 0, stats: null, place: 0, players: 0 }; }
}
const STAFF_ROLES = ['owner', 'coowner', 'founder', 'manager', 'moderator', 'boss', 'vip', 'admin'];
function loadStaff() {
  try { const d = JSON.parse(readFileSync(new URL('./staff.json', import.meta.url), 'utf8')); const o = {}; for (const k in d) if (/^\d{17}$/.test(k) && STAFF_ROLES.includes(d[k])) o[k] = d[k]; return o; }
  catch (e) { console.error('staff', e.message); return {}; }
}
const nameCache = new Map();
async function cachedProfile(id) {
  const c = nameCache.get(id); if (c && Date.now() - c.t < 36e5) return c.p;
  const p = await profile(id); if (p.avatar) nameCache.set(id, { t: Date.now(), p }); return p;
}

async function profile(id) {
  const key = process.env.STEAM_API_KEY;
  const fallback = { id, name: 'Steam ' + id.slice(-6), avatar: '', profileUrl: `https://steamcommunity.com/profiles/${id}` };
  try {
    if (key) {
      const r = await fetch(`https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2/?key=${key}&steamids=${id}`);
      const p = (await r.json()).response.players[0];
      if (p) return { id, name: p.personaname, avatar: p.avatarfull, profileUrl: p.profileurl };
    } else {
      const x = await (await fetch(`https://steamcommunity.com/profiles/${id}?xml=1`)).text();
      const g = t => { const m = new RegExp(`<${t}>(?:<!\\[CDATA\\[)?([\\s\\S]*?)(?:\\]\\]>)?</${t}>`).exec(x); return m && m[1].trim(); };
      if (g('steamID')) return { id, name: g('steamID'), avatar: g('avatarFull'), profileUrl: fallback.profileUrl };
    }
  } catch (e) { console.error(e); }
  return fallback;
}

// Skin loadout хадгалалт: Netlify Blobs (package.json дахь @netlify/blobs). Байхгүй бол 501 → клиент зөвхөн төхөөрөмж дээрээ хадгална.
import { getStore } from './store.mjs';
async function skinStore(name = 'skins') { return getStore(name); }
const SKIN_KEYS = ['swagSkinLoadout', 'swagSkinExtras'];

export default async (req) => {
  const url = new URL(req.url);
  const base = process.env.BASE_URL ? process.env.BASE_URL.replace(/\/$/, '') : url.origin;
  try {
    if (url.pathname === '/auth/steam') {
      const p = new URLSearchParams({ 'openid.ns': NS, 'openid.mode': 'checkid_setup',
        'openid.return_to': base + '/auth/steam/return', 'openid.realm': base,
        'openid.identity': NS + '/identifier_select', 'openid.claimed_id': NS + '/identifier_select' });
      return redirect(OPENID + '?' + p);
    }
    if (url.pathname === '/auth/steam/return') {
      const id = await verify(url, base);
      if (!id) return redirect('/?login=error&why=verify');
      if (!process.env.SESSION_SECRET) return redirect('/?login=error&why=nosecret');
      const pr = await profile(id);
      return redirect('/?login=ok', { 'Set-Cookie': cookieHdr(makeCookie({ ...pr, exp: Date.now() + 30 * 864e5 }), 30 * 86400) });
    }
    if (url.pathname === '/api/me') {
      if (!process.env.SESSION_SECRET) return json(500, { error: 'SESSION_SECRET is not set (set it, then redeploy)' });
      const s = readCookie(req); if (!s) return json(401, { error: 'not_logged_in', hasCookie: /swag=/.test(req.headers.get('cookie') || '') });
      return json(200, { id: s.id, name: s.name, avatar: s.avatar, profileUrl: s.profileUrl, ...(await ratingOf(s.id)), staff: loadStaff()[s.id] || '' });
    }
    if (url.pathname === '/api/pfimg') {
      const kind = url.searchParams.get('kind'); if (kind !== 'banner' && kind !== 'avatar') return json(400, { error: 'bad_kind' });
      let store; try { store = await skinStore('pfimg'); } catch (e) { return json(501, { error: 'storage_unavailable' }); }
      if (req.method === 'GET') {
        const id = url.searchParams.get('id') || ''; if (!/^\d{17}$/.test(id)) return json(400, { error: 'bad_id' });
        const r = await store.getWithMetadata(id + ':' + kind, { type: 'arrayBuffer' });
        if (!r) return json(404, { error: 'none' });
        return new Response(r.data, { status: 200, headers: { 'Content-Type': r.metadata?.type || 'image/webp', 'Cache-Control': 'public, max-age=300' } });
      }
      const me = readCookie(req); if (!me) return json(401, { error: 'not_logged_in' });
      if (req.method === 'DELETE') { await store.delete(me.id + ':' + kind); return json(200, { ok: true }); }
      if (req.method === 'POST') {
        const type = (req.headers.get('content-type') || '').split(';')[0];
        if (!['image/gif', 'image/webp', 'image/jpeg', 'image/png'].includes(type)) return json(415, { error: 'bad_type' });
        const buf = await req.arrayBuffer(); if (buf.byteLength > 4500000) return json(413, { error: 'too_large' });
        await store.set(me.id + ':' + kind, buf, { metadata: { type } }); return json(200, { ok: true });
      }
      return json(405, { error: 'method' });
    }
    if (url.pathname === '/api/skins') {
      const me = readCookie(req); if (!me) return json(401, { error: 'not_logged_in' });
      let store; try { store = await skinStore(); } catch (e) { return json(501, { error: 'storage_unavailable' }); }
      if (req.method === 'POST') {
        const raw = await req.text(); if (raw.length > 400000) return json(413, { error: 'too_large' });
        const b = JSON.parse(raw), out = {};
        for (const k of SKIN_KEYS) if (typeof b[k] === 'string') out[k] = b[k];
        await store.setJSON(me.id, out); return json(200, { ok: true });
      }
      return json(200, (await store.get(me.id, { type: 'json' })) || {});
    }
    if (url.pathname === '/api/team') {
      const st = loadStaff(), ids = Object.keys(st);
      const members = await Promise.all(ids.map(async id => { const pr = await cachedProfile(id); return { id, name: pr.name, avatar: pr.avatar, role: st[id] }; }));
      return json(200, { configured: true, members }, { 'Cache-Control': 'public, max-age=60' });
    }
    if (url.pathname === '/api/player') {
      const id = url.searchParams.get('id') || ''; if (!/^\d{17}$/.test(id)) return json(400, { error: 'bad_id' });
      const r = await ratingOf(id); if (!r.rating) return json(404, { error: 'not_found' });
      const pr = await cachedProfile(id);
      return json(200, { id, name: pr.name, avatar: pr.avatar, profileUrl: pr.profileUrl, ...r, staff: loadStaff()[id] || '' }, { 'Cache-Control': 'public, max-age=60' });
    }
    if (url.pathname === '/api/leaderboard') {
      const all = (await loadAll()).filter(x => x.rating > 0).sort((a, b) => b.rating - a.rating).slice(0, 100);
      const out = await Promise.all(all.map(async x => {
        const pr = await cachedProfile(x.id), st = x.stats || {};
        return { steamid: x.id, name: pr.name, avatar: pr.avatar, exp: x.rating, k: st.kills || 0, d: st.deaths || 0, hs: st.hs || 0, time: st.time || '—', last: '—' };
      }));
      return json(200, out, { 'Cache-Control': 'public, max-age=60' });
    }
    if (url.pathname === '/api/logout') return json(200, { ok: true }, { 'Set-Cookie': cookieHdr('', 0) });
  } catch (e) { console.error(e); return redirect('/?login=error&why=' + encodeURIComponent(String(e.message).slice(0, 80))); }
  return new Response('Not found', { status: 404 });
};
