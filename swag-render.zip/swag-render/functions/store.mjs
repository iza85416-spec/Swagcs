// Netlify Blobs-ийн оронд файлын систем дээр хадгална. Render дээр DATA_DIR-ийг Disk-ийн замтай (жишээ нь /var/data) тааруулна.
import fs from 'node:fs/promises';
import path from 'node:path';

const ROOT = process.env.DATA_DIR || path.join(process.cwd(), 'data');
const safe = k => encodeURIComponent(k);

export function getStore(name) {
  const dir = path.join(ROOT, safe(name));
  const f = k => path.join(dir, safe(k));
  const read = async p => { try { return await fs.readFile(p); } catch { return null; } };
  return {
    async set(key, data, opts = {}) {
      await fs.mkdir(dir, { recursive: true });
      await fs.writeFile(f(key), Buffer.from(data));
      await fs.writeFile(f(key) + '.meta', JSON.stringify(opts.metadata || {}));
    },
    async setJSON(key, obj) { await this.set(key, Buffer.from(JSON.stringify(obj))); },
    async get(key, opts = {}) {
      const b = await read(f(key)); if (!b) return null;
      return opts.type === 'json' ? JSON.parse(b.toString()) : b;
    },
    async getWithMetadata(key) {
      const b = await read(f(key)); if (!b) return null;
      let metadata = {}; try { metadata = JSON.parse((await read(f(key) + '.meta'))?.toString() || '{}'); } catch {}
      return { data: b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength), metadata };
    },
    async delete(key) { await fs.rm(f(key), { force: true }); await fs.rm(f(key) + '.meta', { force: true }); },
  };
}
