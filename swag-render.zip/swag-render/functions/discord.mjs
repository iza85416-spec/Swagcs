// Netlify Function: Discord OAuth2 (scope: identify). Steam-ээр нэвтэрсэн хэрэглэгчийн Discord-ыг холбоно.
// Env: DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET, SESSION_SECRET (steam.mjs-тэй ижил), BASE_URL (заавал биш)
// Discord Developer Portal -> OAuth2 -> Redirects: <BASE_URL>/auth/discord/callback
import crypto from 'node:crypto';

export const config = { path: ['/auth/discord', '/auth/discord/callback', '/api/discord', '/api/discord/unlink'] };

const secret = () => { const s = process.env.SESSION_SECRET; if (!s) throw new Error('SESSION_SECRET is not set'); return s; };
const sign = v => crypto.createHmac('sha256', secret()).update(v).digest('base64url');
const pack = o => { const b = Buffer.from(JSON.stringify(o)).toString('base64url'); return b + '.' + sign(b); };
function unpack(req, name) {
  const m = new RegExp('(?:^|;\\s*)' + name + '=([^;]+)').exec(req.headers.get('cookie') || ''); if (!m) return null;
  const [b, s] = m[1].split('.'); if (!b || !s) return null;
  const a = Buffer.from(sign(b)), c = Buffer.from(s);
  if (a.length !== c.length || !crypto.timingSafeEqual(a, c)) return null;
  try { const o = JSON.parse(Buffer.from(b, 'base64url').toString()); return o.exp > Date.now() ? o : null; } catch { return null; }
}
const ck = (name, v, age) => `${name}=${v}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${age}`;
const json = (code, o, cookies = []) => { const h = new Headers({ 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); cookies.forEach(c => h.append('Set-Cookie', c)); return new Response(JSON.stringify(o), { status: code, headers: h }); };
const redirect = (loc, cookies = []) => { const h = new Headers({ Location: loc }); cookies.forEach(c => h.append('Set-Cookie', c)); return new Response(null, { status: 302, headers: h }); };

export default async (req) => {
  const url = new URL(req.url);
  const base = process.env.BASE_URL ? process.env.BASE_URL.replace(/\/$/, '') : url.origin;
  const id = process.env.DISCORD_CLIENT_ID, sec = process.env.DISCORD_CLIENT_SECRET;
  const configured = !!(id && sec && process.env.SESSION_SECRET);
  try {
    if (url.pathname === '/api/discord') {
      if (!configured) return json(200, { configured: false, linked: false });
      const d = unpack(req, 'swagdc');
      return json(200, { configured: true, linked: !!d, ...(d ? { id: d.id, username: d.username, avatar: d.avatar } : {}) });
    }
    if (url.pathname === '/api/discord/unlink') return json(200, { ok: true }, [ck('swagdc', '', 0)]);
    if (!configured) return redirect('/?discord=error&why=not_configured');
    if (url.pathname === '/auth/discord') {
      if (!unpack(req, 'swag')) return redirect('/?discord=error&why=login_first'); // эхлээд Steam-ээр нэвтэрнэ
      const state = crypto.randomBytes(16).toString('hex');
      const p = new URLSearchParams({ client_id: id, response_type: 'code', scope: 'identify', redirect_uri: base + '/auth/discord/callback', state, prompt: 'consent' });
      return redirect('https://discord.com/oauth2/authorize?' + p, [ck('swagdc_state', pack({ state, exp: Date.now() + 10 * 60e3 }), 600)]);
    }
    if (url.pathname === '/auth/discord/callback') {
      const st = unpack(req, 'swagdc_state');
      if (url.searchParams.get('error')) return redirect('/?discord=error&why=denied', [ck('swagdc_state', '', 0)]);
      if (!st || st.state !== url.searchParams.get('state')) return redirect('/?discord=error&why=state', [ck('swagdc_state', '', 0)]);
      const tr = await fetch('https://discord.com/api/oauth2/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ client_id: id, client_secret: sec, grant_type: 'authorization_code', code: url.searchParams.get('code') || '', redirect_uri: base + '/auth/discord/callback' }) });
      const tok = await tr.json(); if (!tok.access_token) return redirect('/?discord=error&why=token', [ck('swagdc_state', '', 0)]);
      const u = await (await fetch('https://discord.com/api/users/@me', { headers: { Authorization: 'Bearer ' + tok.access_token } })).json();
      if (!u.id) return redirect('/?discord=error&why=user', [ck('swagdc_state', '', 0)]);
      const av = u.avatar ? `https://cdn.discordapp.com/avatars/${u.id}/${u.avatar}.png?size=128` : '';
      return redirect('/?discord=ok', [ck('swagdc_state', '', 0), ck('swagdc', pack({ id: u.id, username: u.global_name || u.username, avatar: av, exp: Date.now() + 30 * 864e5 }), 30 * 86400)]);
    }
  } catch (e) { console.error(e); return redirect('/?discord=error&why=' + encodeURIComponent(String(e.message).slice(0, 60))); }
  return new Response('Not found', { status: 404 });
};
